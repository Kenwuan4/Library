package com.example.demo.controller;


import com.example.demo.model.Book;
import com.example.demo.service.BookService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
public class BookController {
    @Autowired
    BookService bookService;


    @GetMapping("/book")
    private List<Book> getAllBooks(){
        return bookService.getAllBooks();
    }

    @DeleteMapping("/book/{bookid}")
    private void deleteBook(@PathVariable("bookid") int bookid){
        bookService.delete(bookid);
    }

    @PostMapping("/books")
    private int saveBook(@RequestBody Book books)
    {
        bookService.saveOrUpdate(books);
        return books.getId();
    }

    @PutMapping("/books")
    private Book update(@RequestBody Book books)
    {
        bookService.saveOrUpdate(books);
        return books;
    }
}
