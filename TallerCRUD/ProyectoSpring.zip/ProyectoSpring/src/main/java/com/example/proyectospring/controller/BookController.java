package com.example.proyectospring.controller;


import com.example.proyectospring.model.Book;
import com.example.proyectospring.service.BookService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
public class BookController {
    @Autowired
    BookService bookService;

    //R
    @GetMapping("/books")
    private List<Book> getAllBooks(){
        return bookService.getAllBooks();
    }
    @GetMapping("/book/{id}")
    private ResponseEntity<Book> getBook(@PathVariable("id") int id){
        Book book = bookService.findBook(id);
        if(book == null)
            return new ResponseEntity<Book>(null,null, HttpStatus.NOT_FOUND);
        else
            return new ResponseEntity<Book>(book,null, HttpStatus.OK);
    }
    //D
    @DeleteMapping("/book/{id}")
    private ResponseEntity<Book> deleteBook(@PathVariable("id") int id){
        bookService.delete(id);
        if(bookService.findBook(id) != null)
            return new ResponseEntity<Book>(null,null, HttpStatus.OK);
        return null;
    }

    //C
    @PostMapping("/book")
    private ResponseEntity<Book> saveBook(@RequestBody Book book)
    {
        bookService.saveOrUpdate(book);
        return new ResponseEntity<Book>(book,null, HttpStatus.CREATED);
    }
    @PostMapping("/books")
    private void saveBook(@RequestBody List<Book> list_books)
    {
        bookService.saveOrUpdateAll(list_books);
    }
    //U
    @PutMapping("/book")
    private ResponseEntity<Book> update(@RequestBody Book book)
    {
        Book compare = bookService.findBook(book.getId());
        bookService.saveOrUpdate(book);
        if(!book.equals(compare))
            return new ResponseEntity<Book>(book,null, HttpStatus.OK);
        return null;
    }
}
