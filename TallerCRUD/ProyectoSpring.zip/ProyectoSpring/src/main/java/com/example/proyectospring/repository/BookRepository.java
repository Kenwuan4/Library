package com.example.proyectospring.repository;
import com.example.proyectospring.model.Book;
import com.sun.xml.bind.v2.model.core.ID;
import org.springframework.data.jpa.repository.JpaRepository;


import java.util.List;

public interface BookRepository extends JpaRepository<Book, Integer>
{

    List<Book> findAll();

    <S extends Book> S saveAndFlush(S entity);

    Book getById(ID id);

    void deleteById(Integer integer);
}
