package com.example.proyectospring.service;

import com.example.proyectospring.model.Book;
import com.example.proyectospring.repository.BookRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.ArrayList;
import java.util.List;

@Service
public class BookService {

    @Autowired
    BookRepository bookRepository;

    public List<Book> getAllBooks(){
        List<Book> books = new ArrayList<Book>();
        bookRepository.findAll().forEach(book -> books.add(book));
        return books;
    }

    public Book findBook(int id){
        if(bookRepository.findById(id).isPresent())
            return bookRepository.findById(id).get();
        else
            return null;
    }

    public void saveOrUpdate(Book book){
        bookRepository.saveAndFlush(book);
    }

    public void saveOrUpdateAll(List<Book> booksList){
        booksList.forEach(book -> bookRepository.saveAndFlush(book));
    }

    public void delete (int id){
        bookRepository.deleteById(id);
    }




}
